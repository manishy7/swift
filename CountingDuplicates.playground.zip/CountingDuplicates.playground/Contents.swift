import Foundation
func countDuplicates (_ s: String) -> Int {
    let  temp = Array(s)
    let cap = temp.enumerated().map {
        String($0.element).uppercased()
    }



    let duplicates = Array(Set(cap.filter({ (i: String) in cap.filter({ $0 == i }).count > 1})))
    
    print(duplicates)
    let count = duplicates.count
    print(count)
    return count
}
countDuplicates("aaAbcDD")

