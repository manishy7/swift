import Foundation


//func spinWords(in sentence: String) -> String {
//
//    var count = sentence.count
//    // Your code goes here
//    var i: String = ""
//    var temp: String = ""
//    let comments = sentence.components(separatedBy: "")
//    for i in sentence {
//
//
//
//
//
//    }
//
//
//    return temp
//}
//spinWords(in: "Hello world")

var sentence: String = "hi hellow hi world"
let arrayComponets = sentence.components(separatedBy: " ")
var n = 0
var temp = ""
var lastArray: Bool = false
var count = arrayComponets.count - 1
for i in arrayComponets {
  if 5 <= arrayComponets[n].count {
      let components = String(arrayComponets[n].reversed())
      
      temp.append(contentsOf: components)
      temp.append(contentsOf: lastArray ? "" : " ")
      
  }
    if i == arrayComponets.last && arrayComponets[0] != arrayComponets.last{
        lastArray = true
    }

  else {
//      temp.append(contentsOf: arrayComponets[n])
      temp.append(contentsOf: lastArray ? "" : " ")
      
      
  }
    
    
}

print(temp)
print(count)



